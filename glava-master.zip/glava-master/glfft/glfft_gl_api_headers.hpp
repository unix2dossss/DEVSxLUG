
/* Let GLFFT use GLava's headers */
#define GLFFT_GLSL_LANG_STRING "#version 430 core\n"
extern "C" {
    #include "../glava/glad.h"
}
