# TODO

+ Simplify Theme.cpp
+ Editing launchers with exo-desktop-item-edit
+ Exotic windows : Libreoffice / Openoffice (imply changing the group of a window)

## DONE

> + Fix all build warnings
> + Indicator orientation
> + Basic orientation managing
> + Show only windows from active workspace
> + i18n
> + Settings UI
> + Basic workspaces managing
> + Drop down list of windows
> + Icon resizing
> + Pinable dock buttons
> + CSS class
> + Button reordering (d n'd)
> + XDG Desktop Files integration
